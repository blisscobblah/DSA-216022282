package linkedlist;

public class DriverClass {

    private static void print(LinkedList list){
        String data;
        System.out.print("Countries: ");
        for (int i = 0; i < list.getSize(); i++) {
           data = list.get(i);
            System.out.printf(" %s,",data);
        }
        System.out.print("\n\n");

    }
    public static void main(String[] args) {
        LinkedList list = new LinkedList();

        list.addAll(new String[] {"Angola","Togo","SouthAfrica","Kenya","Senegal"});
        print(list);

        list.addFirst("Benin");
        System.out.println("Added Benin to beginning of list");
        print(list);

        list.addLast("Nigeria");
        System.out.println("Added Nigeria to end of list");
        print(list);

        list.removeFirst();
        System.out.println("Removed the element at the beginning of the list");
        print(list);

        list.removeLast();
        System.out.println("Removed the element at the end of the list");
        print(list);

        list.add("Ghana");
        System.out.println("Added Ghana to the list");
        print(list);

        System.out.println("The size of the list is : " + list.getSize());

        System.out.println("Index of Togo is : " + list.indexOf("Togo"));

        System.out.println("The first element is: " + list.getFirst());

        System.out.println("The last element is: " + list.getLast());

        System.out.println("Element at index 3 is : " + list.get(3));

        System.out.println("\nList cleared" );
        list.clear();
        print(list);


    }
}
