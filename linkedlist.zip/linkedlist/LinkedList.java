package linkedlist;

import java.util.Locale;

public class LinkedList {

    private Node head = null;
    private Node tail = null;
    private int size = 0;

    LinkedList() {
    }

    static class Node {
        public String element;
        public Node next;

        Node(String element, Node next) {
            this.element = element;
            this.next = next;
        }
    }

    public void addFirst(String element) {
        Node temp = head;
        head = new Node(element, temp);
        if (size == 0) {
            tail = head;
        }
        size++;
    }

    public void addLast(String element) {
        if (size == 0) {
            addFirst(element);
        } else {
            tail.next = new Node(element, null);
            tail = tail.next;
            size++;
        }
    }


    public void add(String element) {
        if (size != 0) {
            addLast(element);
        } else {
            addFirst(element);
        }
    }

    public void addAll(String[] array) {
        for (String e : array) {
            add(e);
        }
    }

    public int getSize() {
        return size;
    }

    public String getFirst() {
        String element= "";
        if (head != null) {
            element = head.element;
        }
        return element;
    }

    public String getLast() {
        return tail.element;
    }

    public String get(int index) {

        Node currentNode = head;
        String element;
        int i = 0;
        if (index == 0) {
            getFirst();
        } else {
            while (currentNode.next != null) {
                i++;
                currentNode = currentNode.next;
                if (index == i) break;
            }
        }
        element = currentNode.element;
        return element;
    }

    public int indexOf(String element) {
        element = element.toLowerCase();
        Node currentNode = head;
        int i = 0;
        if (currentNode.element.toLowerCase().equals(element)) return i;

        while (currentNode.next != null) {
            i++;
            currentNode = currentNode.next;
            if (currentNode.element.toLowerCase().equals(element)) {
                return i;
            }
        }
        return -1;
    }

    public void clear() {
        head = null;
        tail = null;
        size = 0;
    }

    public String removeFirst() {
        String temp = get(0);
        if (head != null) {
            head = head.next;
            size--;
        }
        return temp;
    }

    public String removeLast() {
        String temp = get(getSize() - 1);
        int i = 0;
        Node currentNode = head;
        while (i != getSize() - 2) {
            currentNode = currentNode.next;
            i++;
        }
        tail = currentNode;
        tail.next = null;
        size--;
        return temp;
    }

}

